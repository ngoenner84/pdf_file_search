from sympy import *

L, D, F1, F2 = symbols('L D F1 F2')

hose = 'PTFE'
mu1 = 0.3
mu2 = 0.3
Fh = 1.67
Fc = 35
Mh = 267 + 501
c = 122.7

equations = [
            D + L - c,
            F1 * (D + L) - (F2 * D) - Mh,
            F1 + Fh - F2,
            mu1 * F1 + mu2 * F2 - Fc
    ]

sols = solve(equations, (L, D, F1, F2))

print(f"\n Summary of inputs............\n")
print(f" Hose type is {hose}")
print(f" Frictional coefficient at point 1 is {mu1}")
print(f" Frictional coefficient at point 2 is {mu2}")
print(f" Net radial hose force is {Fh} N")
print(f" Target connect force is {Fc} N")
print(f" Moment due to hose flex is {Mh} N.mm\n")

print(f" -------------------------------------------------\n")
print(f" Summary of solution set................\n")
print(f" Critical length 'L' is {sols[0][0]:.2f}mm")
print(f" D dimension is {sols[0][1]:.2f}mm")
print(f" Force 1 is {sols[0][2]:.2f} N")
print(f" Force 2 is {sols[0][3]:.2f} N")