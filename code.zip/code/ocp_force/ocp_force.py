from sympy import *

def main():

    # Offset and rotation constants to transform standard line locations. Relative to socket origin.
    deg_rot = 3 # Rotation to solve for new line equation
    offset = 4.5 # Socket datum point vertical offset from aligned centerline

    # TODO: Set up feature expressions in ideal, aligned case

    # Layout Inputs

    # Socket cone equation
    p = 22.42787 # Entry from layout, mm
    theta0_deg = 55 # Entry from layout, degrees, measure CCW from x-axis

    # Conversions and calculations, prep to transform
    rotate = deg_rot * (pi/180) # Converts degree rotation to radians for calculations
    theta0 = theta0_deg * (pi/180) # Converts degree "p" angle to radians for trig calcs
    scalar = 1 + (offset * sin(theta0 + rotate))/p # Scales "p" in normal line equation
    print(float(scalar))

    rotation = Matrix([[cos(rotate), -sin(rotate), 0], [sin(rotate), cos(rotate), 0], [0, 0, 1]]) # Matrix for rotation of line
    translation = Matrix([[1, 0, 0], [0, 1, offset], [0, 0, 1]])
    initial = Matrix([cos(theta0), sin(theta0), -p]) # Generic form of normal line equation, scaled to "p"

    transformed = translation * rotation * initial # Calculates coefficients of rotated line
    #transformed[2] = -p * scalar # Sets "p" value to scaled value to find offset line

    print(f"x0 = {float(initial[2]/initial[0])}, y0 = {float(initial[2]/initial[1])}\nx_new = {float(transformed[2]/transformed[0])}, y_new = {float(transformed[2]/transformed[1])}")

    # TODO: Set up transformations of ideal expressions to account for offset and rotation
    # TODO: Find initial contact with transformed socket position, find transition to next contact, set x-range for analysis
    # TODO: Set up force vs distance plot

    x1 = init_contact()
    phase1_calc()
    print(f"Initial Contact, xp = {x1}")


def phase1_calc():
    xc, yc, dxc, dyc = symbols('xc yc dxc dyc')
    xr, yr, xp, yp = symbols('xr yr xp yp')
    r, m, b, l1 = symbols('r m b l1')

    r = 1.5
    l1 = 55.28
    m = -.6247
    b = 26.7
    xp = 106.8
    yp = 0

    # dyc = m * sqrt(1/(1 + m**2))
    dxc = sqrt(1/(1 + m**2))

    ph1_eq = [
            (xc-xr)**2 + (yc-yr)**2 - r**2,
            m * xc + b - yc,
            (xp-xr)**2 + (yp-yr)**2 - l1**2,
            yc + r*dxc - yr
        ]

    solutions = solve(ph1_eq, (xc, yc, xr, yr))

    sol_select = 0

    for i in range(len(solutions)):
        if solutions[i][0] < solutions[sol_select][0]:
            sol_select = i

    print(f"xc: {solutions[sol_select][0]}")

def init_contact():
    # Equations for initial connection stage
    xc, yc, dxc, dyc = symbols('xc yc dxc dyc')
    xr, yr, xp, yp = symbols('xr yr xp yp')
    r, m, b, l1 = symbols('r m b l1')

    r = 1.5
    l1 = 55.28
    m = -.6247
    b = 26.7
    yr = -4.5
    yp = 0

    # dyc = m * sqrt(1/(1 + m**2))
    dxc = sqrt(1/(1 + m**2))

    ph1_eq = [
            (xc-xr)**2 + (yc-yr)**2 - r**2,
            m * xc + b - yc,
            (xp-xr)**2 + (yp-yr)**2 - l1**2,
            yc + r*dxc - yr
        ]

    x_start = solve(ph1_eq, (xp, xr, xc, yc))

    x_select = 0

    for i in range(len(x_start)):
        if x_start[i][0] > x_start[x_select][0]:
            x_select = i
    
    return x_start[x_select][0]

if __name__ == "__main__":
    main()