from sympy import *

x01 = 59.79
y01 = -14.49
x02 = 49.71
y02 = -7.43

offset = 4.5
angle = 3 * (pi/180)

rotate = Matrix([[cos(angle), -sin(angle), 0], [sin(angle), cos(angle), 0], [0, 0, 1]])
translate = Matrix([[1, 0, 0], [0, 1, offset], [0, 0, 1]])

transform = translate * rotate

new_positions = transform * Matrix([x01, y01, 1])

x11 = float(new_positions[0])
y11 = float(new_positions[1])

print(f"x11 = {x11}, y11 = {y11}")