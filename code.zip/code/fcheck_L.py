from sympy import *

Fc, F1, F2 = symbols('Fc F1 F2')

hose = 'EPDM'
delta = 7 # Valve travel distance
mu1 = 0.58 # Friction coefficient for point 1
mu2 = 0.30 # Friction coefficient for point 2
Fh = 1.67 # Radial hose force, from study, additional weight added
Fp = 27 # Pressure force
L = 18 # Lead-in Length, from forcecheck.py results
c = 104.4 # Overall plug length
D0 = c - L # Overall plug length minus valve travel
Mh = 490 # Moment attributable to hose flex, from study

Fspr = 4.445 * ((3.66 + 2.57) + (delta / 25.4) * (1.17 + 2.38)) # Spring force as a function of valve travel

# Moment equations from presentation
equations = [
            F1 * ((D0 - delta) + L) - (F2 * (D0 - delta)) - Mh,
            F1 + Fh - F2,
            mu1 * F1 + mu2 * F2 + Fspr + Fp - Fc
    ]

# Solve for forces
sols = solve(equations, (Fc, F1, F2))

print(f"\n Summary of inputs............\n")
print(f" Hose type is {hose}")
print(f" Frictional coefficient at point 1 is {mu1}")
print(f" Frictional coefficient at point 2 is {mu2}")
print(f" Net radial hose force is {Fh} N")
print(f" Connection Support Length is {L} mm")
print(f" Moment due to hose flex is {Mh} N.mm\n")

print(f" -------------------------------------------------\n")
print(f" Summary of solution set................\n")
print(f" Connect force at {D0 - delta} is {sols[Fc]:.2f} N")
print(f" Force 1 is {sols[F1]:.2f} N")
print(f" Force 2 is {sols[F2]:.2f} N")