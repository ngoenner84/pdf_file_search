from coupler_tools import tapered_ball_hole

results = tapered_ball_hole(.946, .786, .125, 14.5)
min_taper_dia = results[0]
ball_height = results[1]
print(min_taper_dia)
print(ball_height)