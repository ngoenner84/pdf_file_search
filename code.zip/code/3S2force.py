from sympy import *
from math import *

# Use this program to calculate forces while cones are bringning 3S2 plug into alignment.

Fc, F1, F2 = symbols('Fc F1 F2')

hose = 'PTFE'
mu = 0.30
a = radians(20)
cosa = cos(a)
sina = sin(a)
Fh = 1.67
Mh = -270
f1 = mu * F1
f2 = mu * F2

equations = [
            (-96.42 * F2) + (62.97 * F1) - (59.68 * (F1 * mu)) + (50.90 * (F2 * mu)) - Mh,
            (F1 * cosa) - ((F1 * mu) * sina) + ((F2 * mu) * sina) - (F2 * cosa) - Fh,
            (F2 * sina) + ((F2 * mu) * cosa) + ((F1 * mu) * cosa) + (F1 * sina) - Fc
            ]

sols = solve(equations, (Fc, F1, F2))
print(sols)

f1 = mu * sols[F1]
f2 = mu * sols[F2]

print(f"\n Summary of inputs............\n")
print(f" Hose type is {hose}")
print(f" Frictional coefficient at point 1 is {mu}")
print(f" Net radial hose force is {Fh} N")
print(f" Moment due to hose flex is {Mh} N.mm")
print(f" Ramp angle is {degrees(a)}°\n")

print(f" -------------------------------------------------\n")
print(f" Summary of solution set................\n")
print(f" Connect force 'Fc' is {sols[Fc]:.2f} N")
print(f" Connect force 'F1' {sols[F1]:.2f} N")
print(f" Connect force 'F2' is {sols[F2]:.2f} N")
print(f" Frictional force 'f1' is {f1:.2f} N")
print(f" Frictional force 'f2' is {f2:.2f} N")