from sympy import *
from math import *

def tapered_ball_hole(socket_od, socket_id, ball_dia, drill_angle):
    x, y = symbols('x y')

    # part_id = .786 # ID bore diameter
    # part_od = .946 # OD of part
    r = ball_dia / 2 # 1/2 ball diameter
    alpha = radians(drill_angle / 2) # ball hole half angle, convert to radians
    x1 = 0 # Assume ball centered on vertical axis, tapered bore centered as well
    y1 = r * sin(alpha) + (socket_id / 2)
    m = tan(radians(90) - alpha) # slope of y = mx + b line equation, defining edge of tapered bore
    b = y1 - (r / sin(alpha)) # y-intercept of line equation

    h = (socket_od / 2) - y1 - r # maximum ball height below part OD

    equations = [
                y - (m * x) - b,
                (x)**2 + (y)**2 - (socket_id / 2)**2
                ]

    sols = solve(equations, (x, y))
    # print(sols)

    print(f"\n Summary of inputs............\n")
    print(f" Bore ID is {socket_id}")
    print(f" Ball Ø is {2 * r:.4f}")
    print(f" Bore angle is {degrees(alpha):.2f}°")


    print(f" -------------------------------------------------\n")
    print(f" Summary of solution set................\n")
    print(f" Slope is {m:.2f}")
    print(f" Ball center is at {y1:.4f} in")
    print(f" Y-intercept is at {b:.4f} in\n")
    print(f" Tapered Bore Ø min is {(sols[1][0] * 2):.4f} in\n")
    print(f" Depth of 'h' below part OD is {h:.4f} in\n")
    # print(f" Y is {sols[1][1]:.4f} in")

    results = [(sols[1][0] * 2), h]

    return results

def csv_load():

def csv_write():