from fractions import Fraction

decimal = .3125
fraction = '5/16'

print(f"Fractional readout of decimal is {float(Fraction(decimal))}.")
print(f"Fractional readout of fraction is {float(Fraction(fraction))}.")