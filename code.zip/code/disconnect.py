from sympy import *
from math import *

F1, F2, Fdc = symbols('F1 F2 Fdc')

hose = 'PTFE'
mu1 = 0.15
mu2 = 0.15
muc = 0.30
Fh = 2.25
Fcspr = 25
Fspp = 0
h = Fcspr
alpha = radians(35)
Frad = h * (tan(alpha) - muc)
Mh = 714
f1 = mu1 * F1
f2 = mu2 * F2
L1 = 26.4
L2 = 56.8
D = 94

equations = [
            Mh - (F2 * (L1 + D)) + (F1 * D) - Frad * L2,
            F1 - F2 - Fh - Frad,
            Fspp - f2 - f1 + Fdc
            ]

sols = solve(equations, (F1, F2, Fdc))
print(sols)

print(f"\n Summary of inputs............\n")
print(f" Hose type is {hose}")
print(f" Frictional coefficient at point 1 is {mu1}")
print(f" Frictional coefficient at point 2 is {mu2}")
print(f" Frictional coefficient at point 'c' is {muc}")
print(f" Net radial hose force is {Fh} N")
print(f" Moment due to hose flex is {Mh} N.mm\n")
print(alpha)

print(f" -------------------------------------------------\n")
print(f" Summary of solution set................\n")
print(f" Force 1 is {sols[F1]:.2f} N")
print(f" Force 2 is {sols[F2]:.2f} N")
print(f" Disconnect Force Fdc is {sols[Fdc]:.2f} N")
print(f" Net centering force is {Frad} N")