# ss_pdf_miner
Create a reference document that lists every PDF in a specified directory that references a SafeWay Standard
