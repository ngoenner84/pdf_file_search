import PyPDF2
import os
from tabulate import tabulate

directory = input(r"Paste directory that you would like to search: ")
output = input("Enter description of output text file. ") + ".txt"

# create a pdf file object

data_master = {}

for root, dirs, files in os.walk(directory):
    for name in files:
        
        try:
            # create a pdf reader object
            path_to_pdf = os.path.join(root, name)
            file = open(path_to_pdf, 'rb')
            pdfReader = PyPDF2.PdfFileReader(file)
            pages = pdfReader.numPages

            for page in range(pages):

                # Create a page object
                pageObj = pdfReader.getPage(page)

                # extract text from page
                text = pageObj.extractText()
                for i in range(len(text)):
                    if text[i].upper() == 'S' and text[i + 1].upper() == 'S' and text[i + 2] in ['2', '3', '4', '5', '6'] and int(text[i + 3]) <= 9 and int(text[i + 4]) <= 9:
                        word = text[i] + text[i + 1] + text[i + 2] + text[i + 3] + text[i + 4]
                        if word not in data_master:
                            data_master[word] = [name.split(' ')[0]]
                        else:
                            if name.split(' ')[0] not in data_master[word] and name.split(' ')[0] != 'OBS':
                                data_master[word].append(name.split(' ')[0])
            file.close()

        except:
            print(f"", end = '')

sorted_keys = sorted(data_master)
table = [sorted_keys]
for j in range(len(sorted_keys)):
    for i in range(len(data_master[sorted_keys[j]])):
       if len(table) < i + 2:
           table.append([None]*len(sorted_keys))
       table[i + 1][j] = data_master[sorted_keys[j]][i]

with open(output, 'w') as f:
    f.write(tabulate(table, headers="firstrow", tablefmt="tsv"))