# pdf_file_search
Searches PDF files in specified directory for key text and outputs matching filenames to a text document
