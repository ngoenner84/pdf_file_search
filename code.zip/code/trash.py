from math import *

x = cos(radians(30))
print(x)